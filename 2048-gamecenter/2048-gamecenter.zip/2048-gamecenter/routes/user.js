/*
 * GET users listing.
 */

exports.list = function(req, res){
  //res.render('user', { title: 'Add New User' });
  res.send("respond with a resource");
};