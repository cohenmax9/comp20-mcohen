var express = require('express');
var routes = require('./routes');
var user = require('./routes/user');
var http = require('http');
var path = require('path');
var mongo = require('mongodb');

var app = express();

var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/local';

var db = mongo.Db.connect(mongoUri, function (err, databaseConnection) {
  db = databaseConnection;
});

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(express.bodyParser());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

// development only
if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}

// enable cross origin resource sharing
app.all('*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
 });

app.get('/', function (req, res){
  db.collection("scores", function (err, col){
    var d = col.find().toArray(function(err, x){
      console.log("Error accessing database");
    });
    var html = "<!DOCTYPE HTML><html><head><title>2048 Game Center</title><link href='/gamecenter.css' rel='stylesheet' type='text/css'></head><body><h1>2048 Game Center</h1><table><tr><th><h3>User</h3></th><th><h3>Score</h3></th><th><h3>Time</h3></th></tr>";
    col.find().sort({score:-1}).toArray(function(e, data){
      for (var i = 0; i < data.length; i++) {
        html += "<tr><td>" + data[i].username + "</td>";
        html += "<td>" + data[i].score + "</td>";
        html += "<td>" + data[i].created_at + "</td></tr>";
      }
      html += "</table></body></html>";
      res.send(html);
    });
  });
});

app.get('/users', user.list);

app.get('/scores.json', function (req, res){
  var user = req.query.username;
  if (user == undefined) {
    res.send('[]');
  } 
  else {
    db.collection("scores", function (err, col){
      col.find({username: user}).sort({score:-1}).toArray(function(e,result){
       res.send(result);
      });
    });
  }
});

app.post('/submit.json', function (req, res){
    db.collection("scores", function (er, collection){
      if (req.body.username && req.body.score && req.body.grid){
        var username = req.body.username;
        var score = req.body.score;
        var grid = req.body.grid;
        var parsedScore = parseInt(score, 10);
        var data = {"username": username, "score": parsedScore, "grid": grid, "created_at": new Date()};
        collection.insert(data, function (err, result){
            res.send(result);
        });
      }
  });
});

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
})
