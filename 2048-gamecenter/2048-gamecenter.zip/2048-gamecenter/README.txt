Max Cohen
Comp 20: Web Programming
04/10/2014
README.txt

Assignment 4: Game Center for 2048


All parts of this project have been implemented correctly.

I discussed this assignment with George Brown, Sid Prasad, Victor Chao, Skyler Tom, and Obaid Farooqui.

Credit to Jasper Degens for the boiler plate for the Heroku app and web.js.

I spent approximately 24 hours on this assignment. 

The score and grid of 2048 are stored as a instance variables to the class GameManager. The score can be accessed using this.score, which is the score of the current 2048 game. The grid is a Grid object, which can be accessed in game_manager.js by this.grid, contains the current state of the 2048 game board. Both the score and the grid are located in game_manager.js.

I had to modify game_manager.js in the 2048 game to add a username instance variable to the GameManager class (this.username). I also added a jQuery post to send the data from the game to the server in web.js. This jQuery post sent the username, the score, and the grid from the game to the API "http://intense-plains-5152.herokuapp.com/submit.json".